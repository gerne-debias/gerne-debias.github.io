# EIFER - Supplementary Material Readme

Thank you for having interest in the EIFER project.

This folder contains the ([supplementary material](EIFER_SupplementaryMaterial.pdf)) for the CVPR 2025 Paper:
  Electromyography-Informed Facial Expression Reconstruction for Physiological-Based Synthesis and Analysis
  Tim Büchner, Christoph Anders, Orlando Guntinas-Lichius, Joachim Denzler

The folder `Reconstruction` contains the videos for three test subjects doing different facial movements concerning the different reconstructions methods.
The names for each methods is written below the facial geomtry construction.
Please note, MC-CycleGAN does not contain a face model, thus the space is in the middle is supposed to be black.

The folder `Exp` contains the same movements but with isolated expressions.
